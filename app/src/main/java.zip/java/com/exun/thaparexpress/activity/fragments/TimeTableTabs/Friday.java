package com.exun.thaparexpress.activity.fragments.TimeTableTabs;

import android.support.v4.app.Fragment;
import android.app.ProgressDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.exun.thaparexpress.Helper.SQLiteHandler;
import com.exun.thaparexpress.Helper.SQlite;
import com.exun.thaparexpress.R;
import com.exun.thaparexpress.adapter.TimeTableAdapter;

/**
 * Created by root on 8/14/16.
 */
public class Friday extends Fragment {

    // Log tag
    private static final String TAG = "Friday";
    private Cursor fridayList;

    private RecyclerView recyclerView;
    private SQlite db;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mAdapter;

    private ProgressDialog pDialog;

    private View rootView;

    //String to store batch
    public String batch_code;
    public String branch;
    public String batch;

    private SQLiteHandler database;

    public Friday() {

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_timetable, container, false);

        //SQLiteHandler
        database = new SQLiteHandler(getActivity().getApplicationContext());
        batch_code=database.getUserDetails().get("batch_code");
        branch=database.getUserDetails().get("branch");
        batch=branch+batch_code;

        //Sqlite
        Log.e("database initialised", TAG);
        db = SQlite.getInstance(getActivity().getApplicationContext());

        recyclerView = (RecyclerView) rootView.findViewById(R.id.rv);
        populateLecturesList();

        return rootView;


    }

    private void populateLecturesList() {

        String columns = batch+"_lecture AS lecture, "+batch+"_teacher AS teacher, "+batch+"_venue AS venue, "+"start_time, "+"end_time";

        String where = "id = '5'";
        fridayList = db.fetchColumnsByCondition("timetable", columns, where);
        recyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new TimeTableAdapter(getActivity(), fridayList);
        recyclerView.setAdapter(mAdapter);
    }


    @Override
    public void onResume() {
        super.onResume();

        ((TimeTableAdapter) mAdapter).setOnItemClickListener(new TimeTableAdapter.MyClickListener() {
            @Override
            public void onItemClick(int position, View v) {

                //Intent i =new Intent(getActivity(), EventDetails.class);
                //i.putExtra("event_id",position);
                //getActivity().startActivity(i);
            }
        });


    }
}
